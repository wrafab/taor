For more details on the AdaBox002 Rover project, please visit http://learn.adafruit.com/adabox002/.

Adafruit invests time and resources providing this open source design, please support Adafruit and open-source hardware by purchasing products from Adafruit!

Written by Tyler Cooper for Adafruit Industries.
BSD license, check license.txt for more information

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder BLE-Black-Robot-Rover. Check that the BLE-Black-Robot-Rover folder contains BLE-Black-Robot-Rover.ino.

This code example requires the Adafruit BLE library which can be downloaded from https://github.com/adafruit/Adafruit_BluefruitLE_nRF51

This code example also requires the Adafruit MotorShield library which can be downloaded from https://github.com/adafruit/Adafruit_Motor_Shield_V2_Library
